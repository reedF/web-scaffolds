package com.bill99.plfk.api;

import com.bill99.plfk.util.CustomerUtil;
import com.bill99.plfk.util.StringUtils;
import com.bill99.schema.fo.settlement.SettlementPkiApiRequest;
import com.bill99.schema.fo.settlement.SettlementPkiApiResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;


/**
 * webservices 请求应答码
 * */
public class FoApiPkiWSClient1 {
//	private static final String URL = "https://www.99bill.com/fo-batch-settlement/services";
//	/**
//	 * 用于把请求信息发送给快钱的webservices服务，同时拿到对应的应答信息
//	 * */
//	public static String doit(SettlementPkiApiRequest request) {
////		SettlementPkiApiResponse response = null;
//		InputStreamReader isr=null;
//		BufferedReader br=null;
//		try {
//			// 创建URL
//			URL urlString = new URL(FoApiPkiWSClient1.URL);
//			URLConnection urlConn = urlString.openConnection();
//			urlConn.setRequestProperty("content-type","text/xml;charset=utf-8");
//			urlConn.setDoOutput(true);
//			urlConn.setReadTimeout(1200000);
////			urlConn.setConnectTimeout(1200000);
//			PrintWriter out = new PrintWriter(urlConn.getOutputStream());
//			String postContent = StringUtils.ReqFormat(CustomerUtil.settlementPkiApiRequestToXml(request));
//			if (postContent == null){
//				return null;
//			}
//			out.print(postContent);
//			out.close();
//			urlConn.connect();
//			
//			/*获取服务器端返回信息*/
//			isr=new InputStreamReader(urlConn.getInputStream());
//			StringBuffer sb=new StringBuffer();
//			if(isr!=null){
//				br = new BufferedReader(isr);
//	            String inputLine="";
//	            while ((inputLine = br.readLine())!= null){
//	                sb.append(inputLine);
//	            }
//			}
//            
//            String sbr=new String(sb.toString().getBytes(),"utf-8");
//			if (sbr.length() > 0) {
//				return StringUtils.ResFormat(sbr);
////				response=CustomerUtil.xmlToSettlementPkiApiResponse(StringUtils.ResFormat(sbr));
//			}
//		} catch (MalformedURLException e) {
//			System.out.println(e.toString());
//		} catch (UnsupportedEncodingException e) {
//			System.out.println(e.toString());
//		} catch (IOException e) {
//			System.out.println(e.toString());
//		}finally{
//			try {
//				br.close();
//				isr.close();
//			} catch (IOException e) {
//				br=null;
//				isr=null;
//				e.printStackTrace();
//			}
//		}
//		return null;
//	}
}
