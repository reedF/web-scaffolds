package com.bill99.plfk.test.send;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.bill99.plfk.api.CustomerTool;
import com.bill99.plfk.entity.DealInfoEntity;
import com.bill99.plfk.entity.OrderInfoEntity;
import com.bill99.schema.fo.settlement.BatchSettlementApplyResponse;
import com.bill99.schema.fo.settlement.BatchidQueryResponse;
import com.bill99.schema.fo.settlement.ComplexQueryResponse;
import com.bill99.schema.fo.settlement.Pay2bankResultType;
import com.bill99.schema.fo.settlement.SettlementPkiApiResponse;

public class TestApi {
	public static String pay(String batchId) {
		
		
		/** �汾�� */
		String version = "1.0.1";
		/** �ύ���� */
		String serviceType = "fo.batch.settlement.pay";
		/** �̻���� */
		String memberCode = "10012138842";//"10012138860";//"10012138840";
		/** �������� */
		String featureCode = "F889";

		/** ����ʺ� */
		String payerAcctCode = memberCode + "01";
		/** ���κ� */
		String batchNo ="batchNo_"+ new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		/** �������� */
		String applyDate = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		/** �����̻����� */
		String merchantName = "ѧ������";
		/** �ܽ�� */
		String totalAmt = "10000";
		/** �ܱʶ� */
		String totalCnt = "2";
		/** ���ѷ�ʽ */
		String feeType = "0";
		/** ���� */
		String cur = "RMB";
		/** �Ƿ���֤��� */
		String checkAmtCnt = "0";
		/** �Ƿ�����ʧ�� */
		String batchFail = "0";
		/** ��ֵ��ʽ */
		String rechargeType = "1";
		/** �Ƿ��Զ��˿� */
		String autoRefund = "0";
		/** �Ƿ����֪ͨ */
		String phoneNoteFlag = "0";
		/** Ԥ���ֶ�1 */
		String merchantMemo1 = "memo1";
		/** Ԥ���ֶ�2 */
		String merchantMemo2 = "memo2";
		/** Ԥ���ֶ�3 */
		String merchantMemo3 = "memo3";
		
		/** �̼Ҷ����� */
		String merchantId = "orderid_"+ new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		/** ��� */
		String amt = "5000";
		/** �������� */
		String bank = "�й���������";
		/** ���� */
		String name = "����";
		/** ���� */
		String bankCardNo = "6225881258771673";
		/** ������ */
		String branchBank = "�Ϻ�֧��";
		/** �Թ���˽ */
		String payeeType = "0";
		/** ʡ�� */
		String province = "����";
		/** ���� */
		String city = "";
		/** ��Ǯ���ױ�ע */
		String memo = "��Ǯ��ע";
		/** ���н����ñ�ע */
		String bankPurpose = "���н��ױ�ע";
		/** ���н��ױ�ע */
		String bankMemo = "ѧ��";
		/** �տ֪֪ͨ���� */
		String payeeNote = "֪ͨ����";
		/** �տ�ֻ��� */
		String payeeMobile = "15850693123";
		/** �տ�ʼ� */
		String payeeEmail = "624728369@qq.com";
		/** ����ʱЧ */
		String period = "";
		/** �̻�Ԥ���ֶ�1 */
		String orderMemo1 = "order1";
		/** �̻�Ԥ���ֶ�2 */
		String orderMemo2 = "order2";
		/** �̻�Ԥ���ֶ�3 */
		String orderMemo3 = "order3";

		List<OrderInfoEntity> ordersInfo = new ArrayList<OrderInfoEntity>();
		for (int i = 0; i < 2; i++) {
			OrderInfoEntity orderInfo = new OrderInfoEntity();
			orderInfo.setMerchantId(merchantId + i);
			orderInfo.setAmt(amt);
			orderInfo.setBank(bank);
			orderInfo.setName(name);
//			if(i==0){
//				orderInfo.setBankCardNo("");
//			}else{
				orderInfo.setBankCardNo(bankCardNo);
//			}
			
			orderInfo.setBranchBank(branchBank);
			orderInfo.setPayeeType(payeeType);
			orderInfo.setProvince(province);
			orderInfo.setCity(city);
			orderInfo.setMemo(memo);
			orderInfo.setBankPurpose(bankPurpose);
			orderInfo.setBankMemo(bankMemo);
			orderInfo.setPayeeNote(payeeNote);
			orderInfo.setPayeeMobile(payeeMobile);
			orderInfo.setPayeeEmail(payeeEmail);
			orderInfo.setPeriod(period);
			orderInfo.setMerchantMemo1(orderMemo1);
			orderInfo.setMerchantMemo2(orderMemo2);
			orderInfo.setMerchantMemo3(orderMemo3);
			ordersInfo.add(orderInfo);
		}

		DealInfoEntity dealInfo = new DealInfoEntity();
		dealInfo.setPayerAcctCode(payerAcctCode);
		dealInfo.setBatchNo(batchNo);
		dealInfo.setApplyDate(applyDate);
		dealInfo.setName(merchantName);
		dealInfo.setTotalAmt(totalAmt);
		dealInfo.setTotalCnt(totalCnt);
		dealInfo.setFeeType(feeType);
		dealInfo.setCur(cur);
		dealInfo.setCheckAmtCnt(checkAmtCnt);
		dealInfo.setBatchFail(batchFail);
		dealInfo.setRechargeType(rechargeType);
		dealInfo.setAutoRefund(autoRefund);
		dealInfo.setPhoneNoteFlag(phoneNoteFlag);
		dealInfo.setMerchantMemo1(merchantMemo1);
		dealInfo.setMerchantMemo2(merchantMemo2);
		dealInfo.setMerchantMemo3(merchantMemo3);
		dealInfo.setOrdersInfo(ordersInfo);

		dealInfo.setServiceType(serviceType);
		dealInfo.setVersion(version);
		dealInfo.setFeatureCode(featureCode);
		dealInfo.setMemberCode(memberCode);

		CustomerTool ct = new CustomerTool();
		String result="�ύʧ��";
		if ("F889".equalsIgnoreCase(dealInfo.getFeatureCode())) {
			SettlementPkiApiResponse response = ct.apply_ws(dealInfo);
			System.out.println("-------------------------");
			BatchSettlementApplyResponse bsar = (BatchSettlementApplyResponse) ct
					.unseal(response, dealInfo);// �õ���������
			System.out.println("�ύ�����κ�Ϊ:"
					+ bsar.getResponseBody().getBatchNo());
			System.out.println("����ɹ�����Ϊ:"
					+ bsar.getResponseBody().getTotalApplySuccCnt());
			
	            Pay2bankResultType chen = (Pay2bankResultType) bsar.getResponseBody().getPay2bankLists().get(0);
	            
	            chen.getPay2bank().getMerchantId();

			result="�ύ�ɹ�";
		} else {
			if (ct.apply_ftp(dealInfo)) {
				System.out.println("�ϴ��ɹ�");
				result="�ϴ��ɹ�";
			}
			
		}
		System.out.println("ִ�����");
		return result;
	}

	public static String query1(String batchId) {
		String version = "1.0.1";
		String serviceType = "fo.batch.settlement.batchidquery";
		String memberCode = "10012138840";//10012138840 10011629536
		String featureCode = "F889";
//		String batchNo = "batchNo_20110216133440";
		String batchNo =batchId;
		String listFlag = "0";// �Ƿ���ʾ��ϸ��ϸ
		String page = "1";
		String pageSize = "10";

		DealInfoEntity dealInfo = new DealInfoEntity();
		dealInfo.setBatchNo(batchNo);
		dealInfo.setListFlag(listFlag);
		dealInfo.setPage(page);
		dealInfo.setPageSize(pageSize);
		dealInfo.setServiceType(serviceType);
		dealInfo.setVersion(version);
		dealInfo.setFeatureCode(featureCode);
		dealInfo.setMemberCode(memberCode);

		CustomerTool ct = new CustomerTool();
		
		SettlementPkiApiResponse response = ct.apply_ws(dealInfo);
		BatchidQueryResponse bidqr = (BatchidQueryResponse) ct.unseal(response,
				dealInfo);// �õ���������
		System.out.println("��ѯ���ĸ���ɹ�����Ϊ��" + bidqr.getResponseBody().getBatchList().getTotalApplySuccCnt());
		return "��ѯ������ɹ�����Ϊ��" + bidqr.getResponseBody().getBatchList().getTotalApplySuccCnt();
	}

	public static void query2() {
		String version = "1.0";
		String serviceType = "fo.batch.settlement.complexquery";
		String memberCode = "10012138840";//"10011629536";
		String featureCode = "F889";

		String beginApplyDate = "20140314090000";
		String endApplyDate =   "20140314094031";
		String pageSize = "5000";

		DealInfoEntity dealInfo = new DealInfoEntity();
		dealInfo.setBeginApplyDate(beginApplyDate);
		dealInfo.setEndApplyDate(endApplyDate);
		dealInfo.setPageSize(pageSize);
		dealInfo.setServiceType(serviceType);
		dealInfo.setVersion(version);
		dealInfo.setFeatureCode(featureCode);
		dealInfo.setMemberCode(memberCode);

		CustomerTool ct = new CustomerTool();
		SettlementPkiApiResponse response = ct.apply_ws(dealInfo);
		ComplexQueryResponse cqr = (ComplexQueryResponse) ct.unseal(response,
				dealInfo);//�õ���������
		System.out.println("��ѯ���ı���Ϊ��" + cqr.getResponseBody().getTotalCnt());
	}

	//org.springframework.orm.hibernate3.HibernateSystemException: a different object	with the same identifier value was already associated with the session
	/*
	public static void main(String args[]) {
		String batchNo = "batchNo_"+ new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		
		//System.out.println(batchNo);//batchNo_20110713172538
		pay(batchNo);
		//query1("batchNo_20110713172538");
		//query2();
	}*/
	
	//����
	public static void main(String args[]) {
		  String batchNo = "batchNo_"+ new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		  //String batchNo = "batchNo_201201111";
		  //System.out.println(batchNo);//batchNo_20110713172538
		  pay(batchNo);
		 //query1("201406201509.37");
				//query2();
			}
}
