package test;

import junit.framework.TestCase;

public class Test extends TestCase {

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testQuery1() {
		System.out.println("��ʼ����");
//		fail("Not yet implemented");
	}

}
